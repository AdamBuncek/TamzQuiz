package com.example.myquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MotionEventCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.io.File;

public class Summary extends AppCompatActivity implements GestureDetector.OnGestureListener {

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String KEY_HIGHSCORE = "keyHighScore";

    private TextView congratsText;
    private TextView scoreText;
    private Button playAgainButton;
    private ImageView smallPoint;
    private ImageView bigPoint;

    private int highScore;
    private float x1, x2, y1, y2;
    private static int MIN_DISTANCE = 150;
    private GestureDetector gestureDetector;

    private long backPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        gestureDetector = new GestureDetector(Summary.this, this);

        scoreText = findViewById(R.id.score);
        congratsText = findViewById(R.id.congratsText);
        playAgainButton = findViewById(R.id.againButton);
        smallPoint = findViewById(R.id.smallPoint);
        bigPoint = findViewById(R.id.bigPoint);

        Intent intent = getIntent();
        int score = intent.getIntExtra(Quiz.SCORE, 0);
        updateMessage(score);
        loadHighScore();
        updateHighScore(score);

        YoYo.with(Techniques.FadeIn).duration(1000).repeat(0).playOn(scoreText);
        YoYo.with(Techniques.FadeIn).duration(1000).repeat(0).playOn(congratsText);
        YoYo.with(Techniques.FadeIn).duration(1000).repeat(0).playOn(playAgainButton);
        YoYo.with(Techniques.FadeIn).duration(1000).repeat(0).playOn(smallPoint);
        YoYo.with(Techniques.SlideInRight).duration(1000).repeat(0).playOn(bigPoint);



        playAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent = new Intent(getApplicationContext(), Topics.class);
                startActivity(intent);
            }
        });
    }

    private void updateMessage(int score){
        Log.d("score", String.valueOf(score));
        congratsText.setText("Congratulations. You've earnd " + score + " points.");
    }

    public void loadHighScore(){
        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highScore = prefs.getInt(KEY_HIGHSCORE, 0);
    }

    private void updateHighScore(int highScoreNew){
        highScore += highScoreNew;
        scoreText.setText("Score: " + highScore);

        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_HIGHSCORE, highScore);
        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        menu.findItem(R.id.mute).setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.share){

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, "My highscore is " + highScore);

            startActivity(Intent.createChooser(intent,"Share via"));
        }
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){

        gestureDetector.onTouchEvent(event);

        switch(event.getAction()) {
            case (MotionEvent.ACTION_DOWN) :
                Log.d("msg","Action was DOWN");
                x1 = event.getX();
                y1 = event.getY();
                return true;

            case (MotionEvent.ACTION_UP) :
                Log.d("msg","Action was UP");
                x2 = event.getX();
                y2 = event.getY();

                float valueX = x2 - x1;
                float valueY = y2 - y1;

                if(Math.abs(valueX) > MIN_DISTANCE){
                    if(x2>x1){
                        Log.d("tag", "right swipe");
                    }

                    else{
                        Log.d("tag", "left swipe");
                        YoYo.with(Techniques.SlideInRight).duration(1000).repeat(0).playOn(bigPoint);
                    }
                }
                return true;

            default :
                return super.onTouchEvent(event);
        }
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()){
            finish();
        }
        else{
            Toast.makeText(this, "One more click to close.", Toast.LENGTH_SHORT).show();
        }

        backPressedTime = System.currentTimeMillis();
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

}